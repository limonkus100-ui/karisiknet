const express = require('express');
const session = require('express-session');
const path = require('path');
const fs = require('fs');

const app = express();

// ==================== KONFİGÜRASYON ====================
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, '../frontend')));

// CORS
app.use((req, res, next) => {
    res.header('Access-Control-Allow-Origin', 'http://localhost:3000');
    res.header('Access-Control-Allow-Credentials', 'true');
    res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Authorization');
    res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
    next();
});

// Session
app.use(session({
    secret: 'kafa-karisik-guncel-2026',
    resave: false,
    saveUninitialized: false,
    cookie: { 
        secure: false,
        maxAge: 24 * 60 * 60 * 1000
    }
}));

// Uploads
const uploadsPath = path.join(__dirname, '../frontend/uploads');
if (!fs.existsSync(uploadsPath)) {
    fs.mkdirSync(uploadsPath, { recursive: true });
}
app.use('/uploads', express.static(uploadsPath));

// ==================== VERİ DEPOLAMA FONKSİYONLARI ====================

// Veri dosya yolları
const dataDir = path.join(__dirname, 'data');
const usersFile = path.join(dataDir, 'users.json');
const postsFile = path.join(dataDir, 'posts.json');
const settingsFile = path.join(dataDir, 'settings.json');
const commentsFile = path.join(dataDir, 'comments.json');
const likesFile = path.join(dataDir, 'likes.json');

// Data klasörünü oluştur
if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
}

// Veri yükleme fonksiyonu
function loadData() {
    let data = {
        users: [],
        posts: [],
        settings: {},
        comments: [],
        likes: []
    };
    
    try {
        // users.json
        if (fs.existsSync(usersFile)) {
            const usersContent = fs.readFileSync(usersFile, 'utf8').trim();
            if (usersContent) {
                data.users = JSON.parse(usersContent);
                console.log(`📊 ${data.users.length} kullanıcı yüklendi`);
            }
        }
        
        // Eğer users boşsa, varsayılan admin ekle
        if (data.users.length === 0) {
            data.users = [{
                id: 1,
                username: 'admin',
                password: 'admin123',
                email: 'admin@kafakarışık.com',
                role: 'admin',
                full_name: 'Sistem Yöneticisi',
                bio: 'Sistem yöneticisi',
                created_at: new Date().toISOString(),
                last_login: new Date().toISOString()
            }];
            saveData('users', data.users);
        }
        
        // posts.json
        if (fs.existsSync(postsFile)) {
            const postsContent = fs.readFileSync(postsFile, 'utf8').trim();
            if (postsContent) {
                data.posts = JSON.parse(postsContent);
                console.log(`📝 ${data.posts.length} paylaşım yüklendi`);
            }
        }
        
        // Eğer posts boşsa, varsayılan post ekle
        if (data.posts.length === 0) {
            data.posts = [{
                id: 1,
                title: 'Hoş Geldiniz!',
                content: 'Kafa Karışık Studios yönetim paneline hoş geldiniz. Buradan içeriklerinizi yönetebilirsiniz.',
                image_url: null,
                files: [],
                created_at: new Date().toISOString(),
                updated_at: new Date().toISOString(),
                views: 0,
                likes: 0,
                comments: [],
                author: 'Admin',
                author_id: 1,
                author_role: 'admin'
            }];
            saveData('posts', data.posts);
        }
        
        // settings.json
        if (fs.existsSync(settingsFile)) {
            const settingsContent = fs.readFileSync(settingsFile, 'utf8').trim();
            if (settingsContent) {
                data.settings = JSON.parse(settingsContent);
                console.log(`⚙️ Ayarlar yüklendi`);
            }
        }
        
        // Eğer settings boşsa, varsayılan ayarları ekle
        if (Object.keys(data.settings).length === 0) {
            data.settings = {
                site_title: 'Kafa Karışık Studios',
                hero_text: 'Teknoloji, tasarım ve yazılım dünyasına adım atın. Karmaşık konuları basit ve anlaşılır bir şekilde keşfedin.',
                about_text: 'Merhaba! Ben Kafa Karışık Studios\'un kurucusu. Teknoloji, yazılım ve tasarım alanlarında öğrendiklerimi paylaşmak ve karmaşık konuları herkesin anlayabileceği şekilde basitleştirmek için bu platformu oluşturdum.',
                footer_text: '© 2026 produced by Kafa Karışık Studios',
                slogan_text: 'Karmaşık fikirler, basit çözümler',
                maintenance_mode: 'false',
                youtube_channel: 'https://www.youtube.com/channel/UCsSNuIOzgw60HAIuhLs7TyA'
            };
            saveData('settings', data.settings);
        }
        
        // comments.json
        if (fs.existsSync(commentsFile)) {
            const commentsContent = fs.readFileSync(commentsFile, 'utf8').trim();
            if (commentsContent) {
                data.comments = JSON.parse(commentsContent);
                console.log(`💬 ${data.comments.length} yorum yüklendi`);
            }
        }
        
        // likes.json
        if (fs.existsSync(likesFile)) {
            const likesContent = fs.readFileSync(likesFile, 'utf8').trim();
            if (likesContent) {
                data.likes = JSON.parse(likesContent);
                console.log(`❤️ ${data.likes.length} beğeni yüklendi`);
            }
        }
        
    } catch (error) {
        console.error('❌ Veri yükleme hatası:', error.message);
        
        // Hata durumunda varsayılan veri
        return {
            users: [{
                id: 1,
                username: 'admin',
                password: 'admin123',
                email: 'admin@kafakarışık.com',
                role: 'admin',
                full_name: 'Sistem Yöneticisi',
                bio: 'Sistem yöneticisi',
                created_at: new Date().toISOString(),
                last_login: new Date().toISOString()
            }],
            posts: [{
                id: 1,
                title: 'Hoş Geldiniz!',
                content: 'Kafa Karışık Studios yönetim paneline hoş geldiniz. Buradan içeriklerinizi yönetebilirsiniz.',
                image_url: null,
                files: [],
                created_at: new Date().toISOString(),
                updated_at: new Date().toISOString(),
                views: 0,
                likes: 0,
                comments: [],
                author: 'Admin',
                author_id: 1,
                author_role: 'admin'
            }],
            settings: {
                site_title: 'Kafa Karışık Studios',
                hero_text: 'Teknoloji, tasarım ve yazılım dünyasına adım atın. Karmaşık konuları basit ve anlaşılır bir şekilde keşfedin.',
                about_text: 'Merhaba! Ben Kafa Karışık Studios\'un kurucusu. Teknoloji, yazılım ve tasarım alanlarında öğrendiklerimi paylaşmak ve karmaşık konuları herkesin anlayabileceği şekilde basitleştirmek için bu platformu oluşturdum.',
                footer_text: '© 2026 produced by Kafa Karışık Studios',
                slogan_text: 'Karmaşık fikirler, basit çözümler',
                maintenance_mode: 'false',
                youtube_channel: 'https://www.youtube.com/channel/UCsSNuIOzgw60HAIuhLs7TyA'
            },
            comments: [],
            likes: []
        };
    }
    
    return data;
}

// Veri kaydetme fonksiyonu
function saveData(type, data) {
    try {
        let filePath;
        switch(type) {
            case 'users':
                filePath = usersFile;
                break;
            case 'posts':
                filePath = postsFile;
                break;
            case 'settings':
                filePath = settingsFile;
                break;
            case 'comments':
                filePath = commentsFile;
                break;
            case 'likes':
                filePath = likesFile;
                break;
            default:
                console.error(`❌ Bilinmeyen veri türü: ${type}`);
                return false;
        }
        
        const jsonString = JSON.stringify(data, null, 2);
        fs.writeFileSync(filePath, jsonString, 'utf8');
        console.log(`✅ ${type} verisi kaydedildi`);
        return true;
    } catch (error) {
        console.error(`❌ ${type} kaydetme hatası:`, error.message);
        return false;
    }
}

// Global data değişkeni
let data = loadData();

// ==================== MIDDLEWARE ====================
function requireAuth(req, res, next) {
    if (!req.session.userId) {
        return res.status(401).json({ success: false, error: 'Giriş yapmalısınız' });
    }
    next();
}

function requireAdmin(req, res, next) {
    if (!req.session.userId) {
        return res.status(401).json({ success: false, error: 'Giriş yapmalısınız' });
    }
    
    const user = data.users.find(u => u.id === req.session.userId);
    if (!user || user.role !== 'admin') {
        return res.status(403).json({ success: false, error: 'Admin yetkisi gerekli' });
    }
    
    next();
}

function requireModerator(req, res, next) {
    if (!req.session.userId) {
        return res.status(401).json({ success: false, error: 'Giriş yapmalısınız' });
    }
    
    const user = data.users.find(u => u.id === req.session.userId);
    if (!user || (user.role !== 'moderator' && user.role !== 'admin')) {
        return res.status(403).json({ success: false, error: 'Moderatör veya admin yetkisi gerekli' });
    }
    
    next();
}

// ==================== API ROUTES ====================

// 1. TEST
app.get('/api/test', (req, res) => {
    res.json({ 
        success: true, 
        message: 'API çalışıyor!',
        time: new Date().toISOString()
    });
});

// 2. AUTH
app.post('/api/register', (req, res) => {
    const { username, email, password } = req.body;
    
    if (!username || !email || !password) {
        return res.status(400).json({ success: false, error: 'Tüm alanları doldurun' });
    }
    
    const existingUser = data.users.find(u => 
        u.username.toLowerCase() === username.toLowerCase() || 
        u.email.toLowerCase() === email.toLowerCase()
    );
    
    if (existingUser) {
        return res.status(400).json({ 
            success: false, 
            error: 'Bu kullanıcı adı veya email zaten kullanılıyor' 
        });
    }
    
    const newUser = {
        id: data.users.length > 0 ? Math.max(...data.users.map(u => u.id)) + 1 : 1,
        username,
        email,
        password,
        role: 'user',
        full_name: username,
        bio: 'Yeni üye',
        created_at: new Date().toISOString(),
        last_login: new Date().toISOString()
    };
    
    data.users.push(newUser);
    saveData('users', data.users);
    
    res.json({
        success: true,
        message: 'Kayıt başarılı!',
        user: {
            id: newUser.id,
            username: newUser.username,
            email: newUser.email,
            role: newUser.role
        }
    });
});

app.post('/api/login', (req, res) => {
    const { username, password } = req.body;
    
    if (!username || !password) {
        return res.status(400).json({ success: false, error: 'Kullanıcı adı ve şifre gerekli' });
    }
    
    const user = data.users.find(u => 
        (u.username === username || u.email === username) && 
        u.password === password
    );
    
    if (!user) {
        return res.status(401).json({ success: false, error: 'Hatalı kullanıcı adı veya şifre' });
    }
    
    user.last_login = new Date().toISOString();
    saveData('users', data.users);
    
    req.session.userId = user.id;
    req.session.username = user.username;
    req.session.role = user.role;
    
    res.json({
        success: true,
        user: {
            id: user.id,
            username: user.username,
            email: user.email,
            role: user.role,
            full_name: user.full_name,
            bio: user.bio
        }
    });
});

app.post('/api/admin-login', (req, res) => {
    const { username, password } = req.body;
    
    if (!username || !password) {
        return res.status(400).json({ success: false, error: 'Kullanıcı adı ve şifre gerekli' });
    }
    
    const user = data.users.find(u => 
        u.username === username && 
        u.password === password && 
        u.role === 'admin'
    );
    
    if (!user) {
        return res.status(401).json({ success: false, error: 'Hatalı kullanıcı adı veya şifre veya admin değilsiniz' });
    }
    
    req.session.userId = user.id;
    req.session.username = user.username;
    req.session.role = user.role;
    
    res.json({
        success: true,
        user: {
            id: user.id,
            username: user.username,
            email: user.email,
            role: user.role,
            full_name: user.full_name,
            isAdmin: true
        }
    });
});

app.get('/api/user/profile', requireAuth, (req, res) => {
    const user = data.users.find(u => u.id === req.session.userId);
    if (!user) {
        return res.status(404).json({ success: false, error: 'Kullanıcı bulunamadı' });
    }
    
    res.json({
        success: true,
        user: {
            id: user.id,
            username: user.username,
            email: user.email,
            role: user.role,
            full_name: user.full_name,
            bio: user.bio,
            isAdmin: user.role === 'admin',
            isModerator: user.role === 'moderator' || user.role === 'admin'
        }
    });
});

app.post('/api/logout', (req, res) => {
    req.session.destroy();
    res.json({ success: true, message: 'Çıkış yapıldı' });
});

// 3. POSTS
app.get('/api/posts', (req, res) => {
    const postsWithStats = data.posts.map(post => {
        const postComments = data.comments.filter(c => c.postId === post.id);
        const postLikes = data.likes.filter(l => l.postId === post.id);
        
        return {
            ...post,
            comments: postComments,
            likes: postLikes.length
        };
    });
    
    res.json(postsWithStats);
});

app.post('/api/posts', requireModerator, (req, res) => {
    const { title, content, image_url } = req.body;
    
    if (!title || !content) {
        return res.status(400).json({ success: false, error: 'Başlık ve içerik gerekli' });
    }
    
    const user = data.users.find(u => u.id === req.session.userId);
    const authorName = user ? user.username : 'Anonim';
    
    const newPost = {
        id: data.posts.length > 0 ? Math.max(...data.posts.map(p => p.id)) + 1 : 1,
        title,
        content,
        image_url: image_url || null,
        files: [],
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
        views: 0,
        likes: 0,
        comments: [],
        author: authorName,
        author_id: req.session.userId || 1,
        author_role: user ? user.role : 'user'
    };
    
    data.posts.push(newPost);
    saveData('posts', data.posts);
    
    res.json({
        success: true,
        postId: newPost.id,
        message: 'Post başarıyla oluşturuldu'
    });
});

app.delete('/api/posts/:id', requireModerator, (req, res) => {
    const postId = parseInt(req.params.id);
    const postIndex = data.posts.findIndex(p => p.id === postId);
    
    if (postIndex === -1) {
        return res.status(404).json({ success: false, error: 'Post bulunamadı' });
    }
    
    const user = data.users.find(u => u.id === req.session.userId);
    const post = data.posts[postIndex];
    
    if (user.role === 'moderator' && post.author_id !== user.id) {
        return res.status(403).json({ success: false, error: 'Sadece kendi paylaşımlarınızı silebilirsiniz' });
    }
    
    data.posts.splice(postIndex, 1);
    
    data.comments = data.comments.filter(c => c.postId !== postId);
    data.likes = data.likes.filter(l => l.postId !== postId);
    
    saveData('posts', data.posts);
    saveData('comments', data.comments);
    saveData('likes', data.likes);
    
    res.json({ success: true, message: 'Post silindi' });
});

// 4. SETTINGS
app.get('/api/settings', (req, res) => {
    res.json(data.settings);
});

app.post('/api/settings', requireAdmin, (req, res) => {
    const newSettings = req.body;
    
    data.settings = {
        ...data.settings,
        ...newSettings
    };
    
    saveData('settings', data.settings);
    
    res.json({ success: true, message: 'Ayarlar kaydedildi' });
});

// BAKIM MODU
app.post('/api/settings/maintenance', requireAdmin, (req, res) => {
    console.log('🛠️ Bakım modu isteği:', req.body);
    
    const { enabled } = req.body;
    
    if (enabled === undefined) {
        return res.status(400).json({ success: false, error: 'Enabled parametresi gerekli' });
    }
    
    data.settings.maintenance_mode = enabled ? 'true' : 'false';
    
    saveData('settings', data.settings);
    
    console.log(`✅ Bakım modu ${enabled ? 'açıldı' : 'kapatıldı'}`);
    
    res.json({ 
        success: true, 
        message: `Bakım modu ${enabled ? 'açıldı' : 'kapatıldı'}` 
    });
});

// 5. DASHBOARD STATS
app.get('/api/dashboard/stats', requireModerator, (req, res) => {
    const user = data.users.find(u => u.id === req.session.userId);
    
    let filteredPosts = data.posts;
    if (user.role === 'moderator') {
        filteredPosts = data.posts.filter(post => post.author_id === user.id);
    }
    
    const stats = {
        totalPosts: filteredPosts.length,
        totalUsers: data.users.length,
        totalComments: data.comments.length,
        totalLikes: data.likes.length,
        recentPosts: filteredPosts.slice(-5).reverse()
    };
    
    res.json({
        success: true,
        stats,
        userRole: user.role
    });
});

// 6. LIKES
app.post('/api/posts/:id/like', requireAuth, (req, res) => {
    const postId = parseInt(req.params.id);
    const post = data.posts.find(p => p.id === postId);
    
    if (!post) {
        return res.status(404).json({ success: false, error: 'Post bulunamadı' });
    }
    
    const existingLike = data.likes.find(l => 
        l.postId === postId && l.userId === req.session.userId
    );
    
    if (existingLike) {
        data.likes = data.likes.filter(l => !(l.postId === postId && l.userId === req.session.userId));
        post.likes = Math.max(0, post.likes - 1);
        
        saveData('likes', data.likes);
        saveData('posts', data.posts);
        
        res.json({
            success: true,
            liked: false,
            likeCount: post.likes
        });
    } else {
        const user = data.users.find(u => u.id === req.session.userId);
        const newLike = {
            id: data.likes.length > 0 ? Math.max(...data.likes.map(l => l.id)) + 1 : 1,
            postId,
            userId: req.session.userId,
            username: user?.username || 'Anonim',
            createdAt: new Date().toISOString()
        };
        
        data.likes.push(newLike);
        post.likes = (post.likes || 0) + 1;
        
        saveData('likes', data.likes);
        saveData('posts', data.posts);
        
        res.json({
            success: true,
            liked: true,
            likeCount: post.likes
        });
    }
});

// 7. COMMENTS
app.post('/api/posts/:id/comment', requireAuth, (req, res) => {
    const postId = parseInt(req.params.id);
    const { content } = req.body;
    
    if (!content) {
        return res.status(400).json({ success: false, error: 'Yorum içeriği gerekli' });
    }
    
    const post = data.posts.find(p => p.id === postId);
    
    if (!post) {
        return res.status(404).json({ success: false, error: 'Post bulunamadı' });
    }
    
    const user = data.users.find(u => u.id === req.session.userId);
    
    const newComment = {
        id: data.comments.length > 0 ? Math.max(...data.comments.map(c => c.id)) + 1 : 1,
        postId,
        userId: req.session.userId,
        username: user?.username || 'Anonim',
        content,
        created_at: new Date().toISOString()
    };
    
    data.comments.push(newComment);
    saveData('comments', data.comments);
    
    res.json({
        success: true,
        commentId: newComment.id,
        comment: newComment
    });
});

app.delete('/api/comments/:id', requireModerator, (req, res) => {
    const commentId = parseInt(req.params.id);
    const commentIndex = data.comments.findIndex(c => c.id === commentId);
    
    if (commentIndex === -1) {
        return res.status(404).json({ success: false, error: 'Yorum bulunamadı' });
    }
    
    const user = data.users.find(u => u.id === req.session.userId);
    const comment = data.comments[commentIndex];
    
    if (user.role === 'moderator') {
        const post = data.posts.find(p => p.id === comment.postId);
        if (comment.userId !== user.id && (!post || post.author_id !== user.id)) {
            return res.status(403).json({ success: false, error: 'Bu yorumu silme yetkiniz yok' });
        }
    }
    
    data.comments.splice(commentIndex, 1);
    saveData('comments', data.comments);
    
    res.json({ success: true, message: 'Yorum silindi' });
});

// 8. USERS
app.get('/api/users', requireAdmin, (req, res) => {
    const users = data.users.map(user => ({
        id: user.id,
        username: user.username,
        email: user.email,
        role: user.role,
        full_name: user.full_name,
        bio: user.bio,
        created_at: user.created_at,
        last_login: user.last_login,
        post_count: data.posts.filter(p => p.author_id === user.id).length,
        comment_count: data.comments.filter(c => c.userId === user.id).length
    }));
    
    res.json({ success: true, users });
});

// YENİ ENDPOINT: /api/users/:id/promote (Frontend için)
app.post('/api/users/:id/promote', requireAdmin, (req, res) => {
    const userId = parseInt(req.params.id);
    const userIndex = data.users.findIndex(u => u.id === userId);
    
    if (userIndex === -1) {
        return res.status(404).json({ success: false, error: 'Kullanıcı bulunamadı' });
    }
    
    const adminUser = data.users.find(u => u.id === req.session.userId);
    
    if (userId === adminUser.id) {
        return res.status(400).json({ success: false, error: 'Kendi rolünüzü değiştiremezsiniz' });
    }
    
    data.users[userIndex].role = 'moderator';
    data.users[userIndex].updated_at = new Date().toISOString();
    
    saveData('users', data.users);
    
    res.json({
        success: true,
        message: 'Kullanıcı moderatör yapıldı',
        user: {
            id: data.users[userIndex].id,
            username: data.users[userIndex].username,
            role: data.users[userIndex].role
        }
    });
});

// KULLANICI SİLME (SADECE ADMIN)
app.delete('/api/users/:id', requireAdmin, (req, res) => {
    const userId = parseInt(req.params.id);
    const userIndex = data.users.findIndex(u => u.id === userId);
    
    if (userIndex === -1) {
        return res.status(404).json({ success: false, error: 'Kullanıcı bulunamadı' });
    }
    
    const adminUser = data.users.find(u => u.id === req.session.userId);
    const userToDelete = data.users[userIndex];
    
    // Admin kendini silemez
    if (userId === adminUser.id) {
        return res.status(400).json({ success: false, error: 'Kendinizi silemezsiniz' });
    }
    
    // Admin'i silmeye çalışıyorsa
    if (userToDelete.role === 'admin') {
        return res.status(400).json({ success: false, error: 'Admin kullanıcı silinemez' });
    }
    
    // Kullanıcıyı sil
    data.users.splice(userIndex, 1);
    
    // Kullanıcının postlarını sil (eğer varsa)
    const userPosts = data.posts.filter(post => post.author_id === userId);
    userPosts.forEach(post => {
        const postIndex = data.posts.findIndex(p => p.id === post.id);
        if (postIndex !== -1) {
            data.posts.splice(postIndex, 1);
            
            // İlişkili yorumları ve beğenileri temizle
            data.comments = data.comments.filter(c => c.postId !== post.id);
            data.likes = data.likes.filter(l => l.postId !== post.id);
        }
    });
    
    // Kullanıcının yorumlarını sil
    data.comments = data.comments.filter(c => c.userId !== userId);
    
    // Kullanıcının beğenilerini sil
    data.likes = data.likes.filter(l => l.userId !== userId);
    
    saveData('users', data.users);
    saveData('posts', data.posts);
    saveData('comments', data.comments);
    saveData('likes', data.likes);
    
    console.log(`🗑️ Kullanıcı silindi: ${userToDelete.username} (ID: ${userId}) by ${adminUser.username}`);
    
    res.json({
        success: true,
        message: 'Kullanıcı ve ilişkili verileri başarıyla silindi',
        deletedUser: {
            id: userToDelete.id,
            username: userToDelete.username,
            email: userToDelete.email
        }
    });
});

// YENİ: ADMIN TARAFINDAN KULLANICI ŞİFRESİ DEĞİŞTİRME
app.post('/api/admin/change-user-password', requireAdmin, (req, res) => {
    const { userId, newPassword } = req.body;
    
    if (!userId || !newPassword) {
        return res.status(400).json({ success: false, error: 'Kullanıcı ID ve yeni şifre gerekli' });
    }
    
    if (newPassword.length < 6) {
        return res.status(400).json({ success: false, error: 'Şifre en az 6 karakter olmalı' });
    }
    
    const userIndex = data.users.findIndex(u => u.id === parseInt(userId));
    
    if (userIndex === -1) {
        return res.status(404).json({ success: false, error: 'Kullanıcı bulunamadı' });
    }
    
    const adminUser = data.users.find(u => u.id === req.session.userId);
    
    // Admin kendi şifresini değiştiriyorsa farklı bir endpoint kullanmalı
    if (parseInt(userId) === adminUser.id) {
        return res.status(400).json({ success: false, error: 'Kendi şifrenizi değiştirmek için profil sayfasını kullanın' });
    }
    
    // Şifreyi güncelle
    data.users[userIndex].password = newPassword;
    data.users[userIndex].updated_at = new Date().toISOString();
    
    saveData('users', data.users);
    
    console.log(`🔐 Admin ${adminUser.username}, ${data.users[userIndex].username} kullanıcısının şifresini değiştirdi`);
    
    res.json({
        success: true,
        message: 'Kullanıcı şifresi başarıyla değiştirildi',
        user: {
            id: data.users[userIndex].id,
            username: data.users[userIndex].username
        }
    });
});

// YENİ: ADMIN KENDİ ŞİFRESİNİ DEĞİŞTİRME
app.post('/api/admin/change-admin-password', requireAdmin, (req, res) => {
    const { oldPassword, newPassword, confirmPassword } = req.body;
    
    if (!oldPassword || !newPassword || !confirmPassword) {
        return res.status(400).json({ success: false, error: 'Tüm alanları doldurun' });
    }
    
    if (newPassword !== confirmPassword) {
        return res.status(400).json({ success: false, error: 'Yeni şifreler eşleşmiyor' });
    }
    
    if (newPassword.length < 6) {
        return res.status(400).json({ success: false, error: 'Şifre en az 6 karakter olmalı' });
    }
    
    const adminUser = data.users.find(u => u.id === req.session.userId);
    
    if (!adminUser) {
        return res.status(404).json({ success: false, error: 'Kullanıcı bulunamadı' });
    }
    
    // Eski şifreyi kontrol et
    if (adminUser.password !== oldPassword) {
        return res.status(400).json({ success: false, error: 'Mevcut şifre hatalı' });
    }
    
    // Yeni şifre eskisiyle aynı olmamalı
    if (oldPassword === newPassword) {
        return res.status(400).json({ success: false, error: 'Yeni şifre eski şifreyle aynı olamaz' });
    }
    
    // Şifreyi güncelle
    adminUser.password = newPassword;
    adminUser.updated_at = new Date().toISOString();
    
    saveData('users', data.users);
    
    console.log(`🔐 Admin ${adminUser.username} kendi şifresini değiştirdi`);
    
    res.json({
        success: true,
        message: 'Admin şifresi başarıyla değiştirildi'
    });
});

// Diğer user endpoint'leri
app.post('/api/users/:id/make-moderator', requireAdmin, (req, res) => {
    const userId = parseInt(req.params.id);
    const userIndex = data.users.findIndex(u => u.id === userId);
    
    if (userIndex === -1) {
        return res.status(404).json({ success: false, error: 'Kullanıcı bulunamadı' });
    }
    
    const adminUser = data.users.find(u => u.id === req.session.userId);
    
    if (userId === adminUser.id) {
        return res.status(400).json({ success: false, error: 'Kendi rolünüzü değiştiremezsiniz' });
    }
    
    data.users[userIndex].role = 'moderator';
    data.users[userIndex].updated_at = new Date().toISOString();
    
    saveData('users', data.users);
    
    res.json({
        success: true,
        message: 'Kullanıcı moderatör yapıldı'
    });
});

app.post('/api/users/:id/remove-moderator', requireAdmin, (req, res) => {
    const userId = parseInt(req.params.id);
    const userIndex = data.users.findIndex(u => u.id === userId);
    
    if (userIndex === -1) {
        return res.status(404).json({ success: false, error: 'Kullanıcı bulunamadı' });
    }
    
    const adminUser = data.users.find(u => u.id === req.session.userId);
    
    if (userId === adminUser.id) {
        return res.status(400).json({ success: false, error: 'Kendi rolünüzü değiştiremezsiniz' });
    }
    
    data.users[userIndex].role = 'user';
    data.users[userIndex].updated_at = new Date().toISOString();
    
    saveData('users', data.users);
    
    res.json({
        success: true,
        message: 'Kullanıcı moderatörlükten alındı'
    });
});

// KULLANICI DÜZENLEME (SADECE ADMIN)
app.put('/api/users/:id', requireAdmin, (req, res) => {
    const userId = parseInt(req.params.id);
    const userIndex = data.users.findIndex(u => u.id === userId);
    
    if (userIndex === -1) {
        return res.status(404).json({ success: false, error: 'Kullanıcı bulunamadı' });
    }
    
    const { username, email, role, full_name, bio } = req.body;
    const adminUser = data.users.find(u => u.id === req.session.userId);
    
    // Admin kendini düzenleyemez (rol hariç diğer alanlar)
    if (userId === adminUser.id && role && role !== adminUser.role) {
        return res.status(400).json({ success: false, error: 'Kendi rolünüzü değiştiremezsiniz' });
    }
    
    // Username/email kontrolü (başka bir kullanıcıda var mı?)
    if (username || email) {
        const existingUser = data.users.find((u, index) => 
            index !== userIndex && 
            ((username && u.username.toLowerCase() === username.toLowerCase()) ||
             (email && u.email.toLowerCase() === email.toLowerCase()))
        );
        
        if (existingUser) {
            return res.status(400).json({ 
                success: false, 
                error: 'Bu kullanıcı adı veya email zaten kullanılıyor' 
            });
        }
    }
    
    // Güncelleme
    if (username) data.users[userIndex].username = username;
    if (email) data.users[userIndex].email = email;
    if (role) data.users[userIndex].role = role;
    if (full_name !== undefined) data.users[userIndex].full_name = full_name;
    if (bio !== undefined) data.users[userIndex].bio = bio;
    
    data.users[userIndex].updated_at = new Date().toISOString();
    
    saveData('users', data.users);
    
    console.log(`✏️ Kullanıcı güncellendi: ${data.users[userIndex].username} by ${adminUser.username}`);
    
    res.json({
        success: true,
        message: 'Kullanıcı başarıyla güncellendi',
        user: {
            id: data.users[userIndex].id,
            username: data.users[userIndex].username,
            email: data.users[userIndex].email,
            role: data.users[userIndex].role,
            full_name: data.users[userIndex].full_name,
            bio: data.users[userIndex].bio,
            updated_at: data.users[userIndex].updated_at
        }
    });
});

app.get('/api/moderators', requireAdmin, (req, res) => {
    const moderators = data.users
        .filter(user => user.role === 'moderator' || user.role === 'admin')
        .map(user => ({
            id: user.id,
            username: user.username,
            email: user.email,
            role: user.role,
            created_at: user.created_at,
            last_login: user.last_login
        }));
    
    res.json({ success: true, moderators });
});

// 9. YORUM YÖNETİMİ ENDPOINT'LERİ

// TÜM YORUMLARI GETİR (SADECE ADMIN/MODERATOR)
app.get('/api/admin/comments', requireModerator, (req, res) => {
    const user = data.users.find(u => u.id === req.session.userId);
    
    let allComments = [...data.comments];
    
    // Eğer moderator ise, sadece kendi postlarındaki ve kendi yorumlarını göster
    if (user.role === 'moderator') {
        const moderatorPosts = data.posts.filter(post => post.author_id === user.id);
        const moderatorPostIds = moderatorPosts.map(post => post.id);
        
        allComments = allComments.filter(comment => 
            comment.userId === user.id || // Kendi yorumları
            moderatorPostIds.includes(comment.postId) // Kendi postlarındaki yorumlar
        );
    }
    
    // Yorumları post bilgileri ile birleştir
    const commentsWithDetails = allComments.map(comment => {
        const post = data.posts.find(p => p.id === comment.postId);
        const commentUser = data.users.find(u => u.id === comment.userId);
        const postAuthor = data.users.find(u => u.id === post?.author_id);
        
        return {
            id: comment.id,
            postId: comment.postId,
            postTitle: post ? post.title : 'Silinmiş Post',
            postAuthor: postAuthor ? postAuthor.username : 'Bilinmiyor',
            userId: comment.userId,
            username: comment.username,
            userRole: commentUser ? commentUser.role : 'unknown',
            content: comment.content,
            created_at: comment.created_at,
            canDelete: user.role === 'admin' || 
                      comment.userId === user.id || 
                      (post && post.author_id === user.id)
        };
    });
    
    // Tarihe göre sırala (yeni önce)
    commentsWithDetails.sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
    
    res.json({
        success: true,
        comments: commentsWithDetails,
        totalComments: commentsWithDetails.length,
        userRole: user.role
    });
});

// YORUM SİLME (ADMIN PANEL - Geliştirilmiş)
app.delete('/api/admin/comments/:id', requireModerator, (req, res) => {
    const commentId = parseInt(req.params.id);
    const commentIndex = data.comments.findIndex(c => c.id === commentId);
    
    if (commentIndex === -1) {
        return res.status(404).json({ success: false, error: 'Yorum bulunamadı' });
    }
    
    const user = data.users.find(u => u.id === req.session.userId);
    const comment = data.comments[commentIndex];
    
    // Yetki kontrolü
    if (user.role === 'moderator') {
        const post = data.posts.find(p => p.id === comment.postId);
        if (comment.userId !== user.id && (!post || post.author_id !== user.id)) {
            return res.status(403).json({ 
                success: false, 
                error: 'Bu yorumu silme yetkiniz yok. Sadece kendi yorumlarınızı veya kendi postlarınızdaki yorumları silebilirsiniz.' 
            });
        }
    }
    
    // Yorumu sil
    data.comments.splice(commentIndex, 1);
    saveData('comments', data.comments);
    
    console.log(`🗑️ Yorum silindi (Admin panel): ID ${commentId} by ${user.username}`);
    
    res.json({ 
        success: true, 
        message: 'Yorum başarıyla silindi',
        deletedCommentId: commentId
    });
});

// TÜM POSTLARI GETİR (ADMIN/MODERATOR İÇİN)
app.get('/api/admin/posts', requireModerator, (req, res) => {
    const user = data.users.find(u => u.id === req.session.userId);
    
    let filteredPosts = data.posts;
    
    // Eğer moderator ise, sadece kendi postlarını göster
    if (user.role === 'moderator') {
        filteredPosts = data.posts.filter(post => post.author_id === user.id);
    }
    
    // Post bilgilerini genişlet
    const postsWithDetails = filteredPosts.map(post => {
        const postAuthor = data.users.find(u => u.id === post.author_id);
        const postComments = data.comments.filter(c => c.postId === post.id);
        const postLikes = data.likes.filter(l => l.postId === post.id);
        
        return {
            id: post.id,
            title: post.title,
            content: post.content.substring(0, 100) + (post.content.length > 100 ? '...' : ''),
            author: postAuthor ? postAuthor.username : 'Bilinmiyor',
            author_id: post.author_id,
            author_role: postAuthor ? postAuthor.role : 'user',
            created_at: post.created_at,
            views: post.views || 0,
            likes: postLikes.length,
            comments: postComments.length,
            canDelete: user.role === 'admin' || post.author_id === user.id
        };
    });
    
    // Tarihe göre sırala (yeni önce)
    postsWithDetails.sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
    
    res.json({
        success: true,
        posts: postsWithDetails,
        totalPosts: postsWithDetails.length,
        userRole: user.role
    });
});

// 10. CHANGE PASSWORD (NORMAL KULLANICI İÇİN)
app.post('/api/change-password', requireAuth, (req, res) => {
    const { oldPassword, newPassword, confirmPassword } = req.body;
    
    if (!oldPassword || !newPassword || !confirmPassword) {
        return res.status(400).json({ success: false, error: 'Tüm alanları doldurun' });
    }
    
    if (newPassword !== confirmPassword) {
        return res.status(400).json({ success: false, error: 'Yeni şifreler eşleşmiyor' });
    }
    
    const user = data.users.find(u => u.id === req.session.userId);
    
    if (!user) {
        return res.status(404).json({ success: false, error: 'Kullanıcı bulunamadı' });
    }
    
    if (user.password !== oldPassword) {
        return res.status(400).json({ success: false, error: 'Mevcut şifre hatalı' });
    }
    
    if (oldPassword === newPassword) {
        return res.status(400).json({ success: false, error: 'Yeni şifre eski şifreyle aynı olamaz' });
    }
    
    user.password = newPassword;
    user.updated_at = new Date().toISOString();
    
    saveData('users', data.users);
    
    console.log(`🔐 ${user.username} kullanıcısı şifresini değiştirdi`);
    
    res.json({ success: true, message: 'Şifre başarıyla değiştirildi' });
});

// 11. CHECK AUTH
app.get('/api/check-auth', (req, res) => {
    if (req.session.userId) {
        const user = data.users.find(u => u.id === req.session.userId);
        res.json({
            authenticated: true,
            user: user ? {
                id: user.id,
                username: user.username,
                role: user.role
            } : null
        });
    } else {
        res.json({ authenticated: false });
    }
});

// 12. MODERATOR DASHBOARD
app.get('/api/moderator/dashboard', requireModerator, (req, res) => {
    const user = data.users.find(u => u.id === req.session.userId);
    
    const userPosts = data.posts.filter(post => post.author_id === user.id);
    const userComments = data.comments.filter(comment => comment.userId === user.id);
    
    const stats = {
        myPosts: userPosts.length,
        myComments: userComments.length,
        totalLikes: userPosts.reduce((sum, post) => sum + (post.likes || 0), 0),
        recentPosts: userPosts.slice(-3).reverse()
    };
    
    res.json({
        success: true,
        user: {
            id: user.id,
            username: user.username,
            role: user.role
        },
        stats
    });
});

// 13. ERROR HANDLING
app.use((req, res) => {
    res.status(404).json({ success: false, error: 'Endpoint bulunamadı' });
});

app.use((err, req, res, next) => {
    console.error('❌ Server error:', err);
    res.status(500).json({ success: false, error: 'Sunucu hatası' });
});

// ==================== SUNUCU BAŞLATMA ====================
const PORT = 3000;

app.listen(PORT, () => {
    const moderatorCount = data.users.filter(u => u.role === 'moderator').length;
    console.log(`
    ╔══════════════════════════════════════════════════╗
    ║        🚀 Kafa Karışık Studios API              ║
    ║        http://localhost:${PORT}                    ║
    ╚══════════════════════════════════════════════════╝
    
    ✅ API AKTİF:
       📂 Veri klasörü: ${dataDir}
       
    📊 VERİ DURUMU:
       👤 Kullanıcılar: ${data.users.length}
       🔧 Moderator: ${moderatorCount}
       📝 Paylaşımlar: ${data.posts.length}
       💬 Yorumlar: ${data.comments.length}
       
    🎯 YENİ ENDPOINT'LER:
       POST /api/admin/change-user-password   - Admin başka kullanıcı şifresi değiştirme
       POST /api/admin/change-admin-password  - Admin kendi şifresini değiştirme
       
    🔒 ŞİFRE YÖNETİMİ:
       - Admin kendi şifresini değiştirebilir
       - Admin diğer kullanıcıların şifrelerini değiştirebilir
       - Normal kullanıcılar kendi şifrelerini değiştirebilir
       
    🚀 API HAZIR!
    `);
});