const express = require('express');
const session = require('express-session');
const path = require('path');
const fs = require('fs');

const app = express();

// ==================== KONFİGÜRASYON ====================
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, '../frontend')));

// CORS
app.use((req, res, next) => {
    res.header('Access-Control-Allow-Origin', 'http://localhost:3000');
    res.header('Access-Control-Allow-Credentials', 'true');
    res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Authorization');
    res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
    next();
});

// Session
app.use(session({
    secret: 'kafa-karisik-guncel-2026',
    resave: false,
    saveUninitialized: false,
    cookie: { 
        secure: false,
        maxAge: 24 * 60 * 60 * 1000
    }
}));

// Uploads
const uploadsPath = path.join(__dirname, '../frontend/uploads');
if (!fs.existsSync(uploadsPath)) {
    fs.mkdirSync(uploadsPath, { recursive: true });
}
app.use('/uploads', express.static(uploadsPath));

// ==================== VERİ DEPOLAMA ====================
let data = {
    users: [
        {
            id: 1,
            username: 'admin',
            password: 'admin123',
            email: 'admin@kafakarışık.com',
            role: 'admin',
            full_name: 'Sistem Yöneticisi',
            bio: 'Sistem yöneticisi',
            created_at: new Date().toISOString(),
            last_login: new Date().toISOString()
        }
    ],
    posts: [
        {
            id: 1,
            title: 'Hoş Geldiniz!',
            content: 'Kafa Karışık Studios yönetim paneline hoş geldiniz. Buradan içeriklerinizi yönetebilirsiniz.',
            image_url: null,
            files: [],
            created_at: new Date().toISOString(),
            updated_at: new Date().toISOString(),
            views: 0,
            likes: 0,
            comments: [],
            author: 'Admin',
            author_id: 1
        }
    ],
    settings: {
        site_title: 'Kafa Karışık Studios',
        hero_text: 'Teknoloji, tasarım ve yazılım dünyasına adım atın. Karmaşık konuları basit ve anlaşılır bir şekilde keşfedin.',
        about_text: 'Merhaba! Ben Kafa Karışık Studios\'un kurucusu. Teknoloji, yazılım ve tasarım alanlarında öğrendiklerimi paylaşmak ve karmaşık konuları herkesin anlayabileceği şekilde basitleştirmek için bu platformu oluşturdum.',
        footer_text: '© 2026 produced by Kafa Karışık Studios',
        slogan_text: 'Karmaşık fikirler, basit çözümler',
        maintenance_mode: 'false',
        youtube_channel: 'https://www.youtube.com/channel/UCsSNuIOzgw60HAIuhLs7TyA'
    },
    files: [],
    comments: [],
    likes: []
};

// ==================== MIDDLEWARE ====================
function requireAuth(req, res, next) {
    if (!req.session.userId) {
        return res.status(401).json({ success: false, error: 'Giriş yapmalısınız' });
    }
    next();
}

function requireAdmin(req, res, next) {
    if (!req.session.userId) {
        return res.status(401).json({ success: false, error: 'Giriş yapmalısınız' });
    }
    
    const user = data.users.find(u => u.id === req.session.userId);
    if (!user || user.role !== 'admin') {
        return res.status(403).json({ success: false, error: 'Admin yetkisi gerekli' });
    }
    
    next();
}

// ==================== API ROUTES ====================

// 1. TEST
app.get('/api/test', (req, res) => {
    res.json({ 
        success: true, 
        message: 'API çalışıyor!',
        time: new Date().toISOString()
    });
});

// 2. AUTH - GÜNCELLENDİ
app.post('/api/register', (req, res) => {
    console.log('👤 Registration request:', req.body.username);
    
    const { username, email, password } = req.body;
    
    if (!username || !email || !password) {
        return res.status(400).json({ success: false, error: 'Tüm alanları doldurun' });
    }
    
    if (username.length < 3) {
        return res.status(400).json({ success: false, error: 'Kullanıcı adı en az 3 karakter olmalı' });
    }
    
    if (password.length < 6) {
        return res.status(400).json({ success: false, error: 'Şifre en az 6 karakter olmalı' });
    }
    
    // Email format kontrolü
    const emailRegex = /\S+@\S+\.\S+/;
    if (!emailRegex.test(email)) {
        return res.status(400).json({ success: false, error: 'Geçerli bir email adresi girin' });
    }
    
    // Kullanıcı adı ve email kontrolü
    const existingUser = data.users.find(u => 
        u.username.toLowerCase() === username.toLowerCase() || 
        u.email.toLowerCase() === email.toLowerCase()
    );
    
    if (existingUser) {
        return res.status(400).json({ 
            success: false, 
            error: 'Bu kullanıcı adı veya email zaten kullanılıyor' 
        });
    }
    
    // Yeni kullanıcı oluştur
    const newUser = {
        id: data.users.length > 0 ? Math.max(...data.users.map(u => u.id)) + 1 : 1,
        username,
        email,
        password, // Gerçek uygulamada hash'lenmeli!
        role: 'user',
        full_name: username,
        bio: 'Yeni üye',
        created_at: new Date().toISOString(),
        last_login: new Date().toISOString()
    };
    
    data.users.push(newUser);
    
    console.log(`✅ New user registered: ${username} (ID: ${newUser.id})`);
    
    res.json({
        success: true,
        message: 'Kayıt başarılı! Şimdi giriş yapabilirsiniz.',
        user: {
            id: newUser.id,
            username: newUser.username,
            email: newUser.email,
            role: newUser.role
        }
    });
});

app.post('/api/login', (req, res) => {
    console.log('🔐 Login request:', req.body.username);
    
    const { username, password } = req.body;
    
    if (!username || !password) {
        return res.status(400).json({ success: false, error: 'Kullanıcı adı ve şifre gerekli' });
    }
    
    const user = data.users.find(u => 
        (u.username === username || u.email === username) && 
        u.password === password
    );
    
    if (!user) {
        return res.status(401).json({ success: false, error: 'Hatalı kullanıcı adı veya şifre' });
    }
    
    // Son giriş zamanını güncelle
    user.last_login = new Date().toISOString();
    
    // Session oluştur
    req.session.userId = user.id;
    req.session.username = user.username;
    req.session.role = user.role;
    
    console.log('✅ Login successful:', user.username);
    
    res.json({
        success: true,
        user: {
            id: user.id,
            username: user.username,
            email: user.email,
            role: user.role,
            full_name: user.full_name,
            bio: user.bio,
            created_at: user.created_at,
            last_login: user.last_login
        }
    });
});

app.post('/api/admin-login', (req, res) => {
    console.log('🔐 Admin login:', req.body.username);
    
    const { username, password } = req.body;
    
    if (!username || !password) {
        return res.status(400).json({ success: false, error: 'Kullanıcı adı ve şifre gerekli' });
    }
    
    const user = data.users.find(u => 
        u.username === username && 
        u.password === password && 
        u.role === 'admin'
    );
    
    if (!user) {
        return res.status(401).json({ success: false, error: 'Hatalı kullanıcı adı veya şifre veya admin değilsiniz' });
    }
    
    req.session.userId = user.id;
    req.session.username = user.username;
    req.session.role = user.role;
    
    console.log('✅ Admin giriş başarılı:', user.username);
    
    res.json({
        success: true,
        user: {
            id: user.id,
            username: user.username,
            email: user.email,
            role: user.role,
            full_name: user.full_name,
            isAdmin: true
        }
    });
});

app.get('/api/user/profile', requireAuth, (req, res) => {
    const user = data.users.find(u => u.id === req.session.userId);
    if (!user) {
        return res.status(404).json({ success: false, error: 'Kullanıcı bulunamadı' });
    }
    
    res.json({
        success: true,
        user: {
            id: user.id,
            username: user.username,
            email: user.email,
            role: user.role,
            full_name: user.full_name,
            bio: user.bio,
            created_at: user.created_at,
            last_login: user.last_login,
            isAdmin: user.role === 'admin'
        }
    });
});

app.post('/api/logout', (req, res) => {
    req.session.destroy();
    res.json({ success: true, message: 'Çıkış yapıldı' });
});

// 3. POSTS
app.get('/api/posts', (req, res) => {
    console.log('📄 Posts requested');
    
    // Posts'ları comments ve likes ile birlikte gönder
    const postsWithStats = data.posts.map(post => {
        const postComments = data.comments.filter(c => c.postId === post.id);
        const postLikes = data.likes.filter(l => l.postId === post.id);
        
        return {
            ...post,
            comments: postComments,
            likes: postLikes.length
        };
    });
    
    res.json(postsWithStats);
});

app.post('/api/posts', requireAdmin, (req, res) => {
    console.log('➕ New post request:', req.body);
    
    const { title, content, image_url } = req.body;
    
    if (!title || !content) {
        return res.status(400).json({ success: false, error: 'Başlık ve içerik gerekli' });
    }
    
    const newPost = {
        id: data.posts.length > 0 ? Math.max(...data.posts.map(p => p.id)) + 1 : 1,
        title,
        content,
        image_url: image_url || null,
        files: [],
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
        views: 0,
        likes: 0,
        comments: [],
        author: 'Admin',
        author_id: req.session.userId || 1
    };
    
    data.posts.push(newPost);
    
    console.log(`✅ New post created: "${title}" (ID: ${newPost.id})`);
    
    res.json({
        success: true,
        postId: newPost.id,
        message: 'Post başarıyla oluşturuldu'
    });
});

app.delete('/api/posts/:id', requireAdmin, (req, res) => {
    const postId = parseInt(req.params.id);
    const postIndex = data.posts.findIndex(p => p.id === postId);
    
    if (postIndex === -1) {
        return res.status(404).json({ success: false, error: 'Post bulunamadı' });
    }
    
    data.posts.splice(postIndex, 1);
    
    // İlişkili yorumları ve beğenileri temizle
    data.comments = data.comments.filter(c => c.postId !== postId);
    data.likes = data.likes.filter(l => l.postId !== postId);
    
    console.log(`🗑️ Post deleted: ID ${postId}`);
    
    res.json({ success: true, message: 'Post silindi' });
});

// 4. SETTINGS
app.get('/api/settings', (req, res) => {
    console.log('⚙️ Settings requested');
    res.json(data.settings);
});

app.post('/api/settings', requireAdmin, (req, res) => {
    console.log('⚙️ Updating settings:', req.body);
    
    const newSettings = req.body;
    
    data.settings = {
        ...data.settings,
        ...newSettings
    };
    
    console.log('✅ Settings updated');
    
    res.json({ success: true, message: 'Ayarlar kaydedildi' });
});

app.post('/api/settings/maintenance', requireAdmin, (req, res) => {
    console.log('🛠️ Maintenance mode request:', req.body);
    
    const { enabled } = req.body;
    
    if (enabled === undefined) {
        return res.status(400).json({ success: false, error: 'Enabled parametresi gerekli' });
    }
    
    data.settings.maintenance_mode = enabled ? 'true' : 'false';
    
    console.log(`✅ Maintenance mode ${enabled ? 'enabled' : 'disabled'}`);
    
    res.json({ 
        success: true, 
        message: `Bakım modu ${enabled ? 'açıldı' : 'kapatıldı'}` 
    });
});

// 5. DASHBOARD STATS
app.get('/api/dashboard/stats', requireAdmin, (req, res) => {
    const stats = {
        totalPosts: data.posts.length,
        totalUsers: data.users.length,
        totalComments: data.comments.length,
        totalLikes: data.likes.length,
        recentPosts: data.posts.slice(-5).reverse()
    };
    
    res.json({
        success: true,
        stats
    });
});

// 6. LIKES - GÜNCELLENDİ
app.post('/api/posts/:id/like', requireAuth, (req, res) => {
    const postId = parseInt(req.params.id);
    const post = data.posts.find(p => p.id === postId);
    
    if (!post) {
        return res.status(404).json({ success: false, error: 'Post bulunamadı' });
    }
    
    // Kullanıcı daha önce beğenmiş mi kontrol et
    const existingLike = data.likes.find(l => 
        l.postId === postId && l.userId === req.session.userId
    );
    
    if (existingLike) {
        // Beğeniyi kaldır
        data.likes = data.likes.filter(l => !(l.postId === postId && l.userId === req.session.userId));
        post.likes = Math.max(0, post.likes - 1);
        
        res.json({
            success: true,
            liked: false,
            likeCount: post.likes,
            message: 'Beğeni kaldırıldı'
        });
    } else {
        // Beğeni ekle
        const user = data.users.find(u => u.id === req.session.userId);
        const newLike = {
            id: data.likes.length > 0 ? Math.max(...data.likes.map(l => l.id)) + 1 : 1,
            postId,
            userId: req.session.userId,
            username: user?.username || 'Anonim',
            createdAt: new Date().toISOString()
        };
        
        data.likes.push(newLike);
        post.likes = (post.likes || 0) + 1;
        
        res.json({
            success: true,
            liked: true,
            likeCount: post.likes,
            message: 'Beğenildi'
        });
    }
});

// 7. COMMENTS - GÜNCELLENDİ
app.post('/api/posts/:id/comment', requireAuth, (req, res) => {
    const postId = parseInt(req.params.id);
    const { content } = req.body;
    
    if (!content) {
        return res.status(400).json({ success: false, error: 'Yorum içeriği gerekli' });
    }
    
    const post = data.posts.find(p => p.id === postId);
    
    if (!post) {
        return res.status(404).json({ success: false, error: 'Post bulunamadı' });
    }
    
    const user = data.users.find(u => u.id === req.session.userId);
    
    const newComment = {
        id: data.comments.length > 0 ? Math.max(...data.comments.map(c => c.id)) + 1 : 1,
        postId,
        userId: req.session.userId,
        username: user?.username || 'Anonim',
        content,
        created_at: new Date().toISOString()
    };
    
    data.comments.push(newComment);
    
    res.json({
        success: true,
        commentId: newComment.id,
        message: 'Yorum eklendi',
        comment: newComment
    });
});

// 8. USERS
app.get('/api/users', requireAdmin, (req, res) => {
    const users = data.users.map(user => ({
        id: user.id,
        username: user.username,
        email: user.email,
        role: user.role,
        created_at: user.created_at,
        last_login: user.last_login
    }));
    
    res.json({ success: true, users });
});

// 9. CHANGE PASSWORD
app.post('/api/change-password', requireAuth, (req, res) => {
    const { oldPassword, newPassword } = req.body;
    
    if (!oldPassword || !newPassword) {
        return res.status(400).json({ success: false, error: 'Tüm alanları doldurun' });
    }
    
    const user = data.users.find(u => u.id === req.session.userId);
    
    if (!user) {
        return res.status(404).json({ success: false, error: 'Kullanıcı bulunamadı' });
    }
    
    if (user.password !== oldPassword) {
        return res.status(400).json({ success: false, error: 'Mevcut şifre hatalı' });
    }
    
    user.password = newPassword;
    
    res.json({ success: true, message: 'Şifre başarıyla değiştirildi' });
});

// 10. USER ACTIVITY
app.get('/api/user/:id/likes', requireAuth, (req, res) => {
    const userId = parseInt(req.params.id);
    
    if (userId !== req.session.userId) {
        return res.status(403).json({ success: false, error: 'Yetkiniz yok' });
    }
    
    const userLikes = data.likes.filter(l => l.userId === userId);
    const likedPosts = userLikes.map(like => {
        const post = data.posts.find(p => p.id === like.postId);
        return {
            post_id: like.postId,
            post_title: post?.title || 'Bilinmeyen',
            post_content: post?.content || '',
            created_at: like.createdAt
        };
    });
    
    res.json(likedPosts);
});

// 11. CHECK AUTH STATUS
app.get('/api/check-auth', (req, res) => {
    if (req.session.userId) {
        const user = data.users.find(u => u.id === req.session.userId);
        res.json({
            authenticated: true,
            user: user ? {
                id: user.id,
                username: user.username,
                role: user.role
            } : null
        });
    } else {
        res.json({ authenticated: false });
    }
});

// ==================== SUNUCU BAŞLATMA ====================
const PORT = 3000;

app.listen(PORT, () => {
    console.log(`
    ╔══════════════════════════════════════╗
    ║     🚀 Kafa Karışık Studios API     ║
    ║     http://localhost:${PORT}           ║
    ╚══════════════════════════════════════╝
    
    ✅ TAM ÇALIŞAN SİSTEM:
       1. Kullanıcı kayıt sistemi ✓
       2. Giriş/çıkış sistemi ✓
       3. Admin panel paylaşım ekleme ✓
       4. Beğeni ve yorum sistemi ✓
       5. Bakım modu ✓
    
    📌 ÖNEMLİ ENDPOINT'LER:
       POST /api/register           - Kullanıcı kaydı
       POST /api/login              - Kullanıcı girişi
       POST /api/admin-login        - Admin girişi
       POST /api/posts              - Yeni içerik ekle
       POST /api/logout             - Çıkış yap
    
    📌 VARSYILAN HESAPLAR:
       👤 Admin: admin / admin123
       👤 Kullanıcı: user / user123 (kayıt olarak oluştur)
    `);
});